from __future__ import annotations

from decimal import Decimal
from typing import Any, Callable

from PySide6.QtCore import QDate, Qt, QThreadPool, QTimer
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QButtonGroup, QFormLayout, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton,
    QRadioButton, QScrollArea, QSpinBox, QTabWidget, QTableWidget, QTableWidgetItem, QTextEdit,
    QVBoxLayout, QWidget, QHeaderView, QAbstractItemView,
)

from app.domain import (
    CUSTOMER_TRANSACTION_LABELS, SUPPORTED_CURRENCIES, convert_to_try,
    default_wholesale_price, line_total,
)
from app.services.product_template import IMAGE_HEADERS, INTEGRATION_HEADERS
from app.ui.workers import Worker
from app.utils.formatting import format_money

ROLE_ITEM = Qt.ItemDataRole.UserRole


def money_spin(maximum: float = 999_999_999_999.0, decimals: int = 2) -> QDoubleSpinBox:
    spin = QDoubleSpinBox()
    spin.setDecimals(decimals)
    spin.setRange(0, maximum)
    spin.setGroupSeparatorShown(True)
    spin.setSingleStep(100)
    return spin


def rate_spin() -> QDoubleSpinBox:
    spin = QDoubleSpinBox()
    spin.setDecimals(6)
    spin.setRange(0.000001, 1_000_000)
    spin.setValue(1)
    return spin


def base_buttons(dialog: QDialog) -> QDialogButtonBox:
    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
    buttons.button(QDialogButtonBox.StandardButton.Save).setText("Kaydet")
    buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Vazgeç")
    buttons.accepted.connect(dialog.accept)
    buttons.rejected.connect(dialog.reject)
    return buttons


class CustomerDialog(QDialog):
    def __init__(self, existing: dict[str, Any] | None = None, parent=None):
        super().__init__(parent)
        self.existing = existing or {}
        self.setWindowTitle("Müşteri Kartı")
        self.setMinimumWidth(600)
        root = QVBoxLayout(self)
        form = QFormLayout()
        self.name = QLineEdit(str(self.existing.get("name") or ""))
        self.code = QLineEdit(str(self.existing.get("code") or ""))
        self.tax_no = QLineEdit(str(self.existing.get("tax_no") or ""))
        self.phone = QLineEdit(str(self.existing.get("phone") or ""))
        self.email = QLineEdit(str(self.existing.get("email") or ""))
        self.address = QTextEdit(str(self.existing.get("address") or "")); self.address.setMaximumHeight(70)
        self.notes = QTextEdit(str(self.existing.get("notes") or "")); self.notes.setMaximumHeight(70)
        self.active = QCheckBox("Aktif müşteri"); self.active.setChecked(bool(self.existing.get("is_active", True)))
        for label, widget in [
            ("Müşteri adı *", self.name), ("Cari kod", self.code), ("Vergi / TC no", self.tax_no),
            ("Telefon", self.phone), ("E-posta", self.email), ("Adres", self.address),
            ("Not", self.notes), ("Durum", self.active),
        ]:
            form.addRow(label, widget)
        root.addLayout(form)
        buttons = base_buttons(self)
        buttons.accepted.disconnect()
        buttons.accepted.connect(self._accept)
        root.addWidget(buttons)

    def _accept(self) -> None:
        if not self.name.text().strip():
            QMessageBox.warning(self, "Eksik Bilgi", "Müşteri adı boş bırakılamaz")
            return
        self.accept()

    def payload(self) -> dict[str, Any]:
        return {
            "name": self.name.text().strip(), "code": self.code.text().strip() or None,
            "tax_no": self.tax_no.text().strip() or None, "phone": self.phone.text().strip() or None,
            "email": self.email.text().strip() or None, "address": self.address.toPlainText().strip() or None,
            "notes": self.notes.toPlainText().strip() or None, "is_active": self.active.isChecked(),
        }


class CustomerTransactionDialog(QDialog):
    def __init__(
        self, customers: list[dict[str, Any]], existing: dict[str, Any] | None = None,
        branch_name: str = "", parent=None,
    ):
        super().__init__(parent)
        self.existing = existing or {}
        self.setWindowTitle("Müşteri Cari İşlemi")
        self.setMinimumWidth(620)
        root = QVBoxLayout(self)
        if branch_name:
            banner = QLabel(f"Kayıt şubesi: {branch_name}")
            banner.setStyleSheet("background:#fff0f0;color:#8f1111;padding:10px;border:1px solid #efc2c2;font-weight:700;")
            root.addWidget(banner)
        form = QFormLayout()
        self.customer = QComboBox()
        for row in customers: self.customer.addItem(row["name"], row["id"])
        self.tx_type = QComboBox()
        for key, label in CUSTOMER_TRANSACTION_LABELS.items():
            if key != "SALE": self.tx_type.addItem(label, key)
        self.amount = money_spin()
        self.currency = QComboBox(); self.currency.addItems(SUPPORTED_CURRENCIES)
        self.fx_rate = rate_spin()
        self.tx_date = QDateEdit(QDate.currentDate()); self.tx_date.setCalendarPopup(True)
        self.has_due = QCheckBox("Vade kullan")
        self.due_date = QDateEdit(QDate.currentDate().addDays(30)); self.due_date.setCalendarPopup(True); self.due_date.setEnabled(False)
        self.payment_method = QComboBox(); self.payment_method.addItems(["Nakit", "Kredi kartı", "Havale / EFT", "Cari / Vadeli", "Diğer"])
        self.document_no = QLineEdit()
        self.description = QTextEdit(); self.description.setMaximumHeight(80)
        for label, widget in [
            ("Müşteri *", self.customer), ("İşlem türü *", self.tx_type), ("Tutar *", self.amount),
            ("Para birimi", self.currency), ("1 birim kaç TL?", self.fx_rate),
            ("İşlem tarihi", self.tx_date), ("Vade", self.has_due), ("Vade tarihi", self.due_date),
            ("Ödeme yöntemi", self.payment_method), ("Belge no", self.document_no), ("Açıklama", self.description),
        ]: form.addRow(label, widget)
        root.addLayout(form)
        self.has_due.toggled.connect(self.due_date.setEnabled)
        self.currency.currentTextChanged.connect(self._currency_changed)
        self._load_existing()
        buttons = base_buttons(self); buttons.accepted.disconnect(); buttons.accepted.connect(self._accept); root.addWidget(buttons)

    @staticmethod
    def _select(combo: QComboBox, value: Any) -> None:
        idx = combo.findData(value)
        if idx >= 0: combo.setCurrentIndex(idx)

    def _load_existing(self) -> None:
        if not self.existing: return
        self._select(self.customer, self.existing.get("customer_id"))
        self._select(self.tx_type, self.existing.get("transaction_type"))
        self.amount.setValue(float(self.existing.get("amount") or 0))
        idx = self.currency.findText(str(self.existing.get("currency") or "TRY")); self.currency.setCurrentIndex(max(idx, 0))
        self.fx_rate.setValue(float(self.existing.get("fx_rate_to_try") or 1))
        if self.existing.get("transaction_date"):
            self.tx_date.setDate(QDate.fromString(str(self.existing["transaction_date"])[:10], "yyyy-MM-dd"))
        if self.existing.get("due_date"):
            self.has_due.setChecked(True); self.due_date.setDate(QDate.fromString(str(self.existing["due_date"])[:10], "yyyy-MM-dd"))
        idx = self.payment_method.findText(str(self.existing.get("payment_method") or ""))
        if idx >= 0: self.payment_method.setCurrentIndex(idx)
        self.document_no.setText(str(self.existing.get("document_no") or ""))
        self.description.setPlainText(str(self.existing.get("description") or ""))

    def _currency_changed(self, currency: str) -> None:
        if currency == "TRY": self.fx_rate.setValue(1); self.fx_rate.setEnabled(False)
        else: self.fx_rate.setEnabled(True)

    def _accept(self) -> None:
        if not self.customer.currentData(): QMessageBox.warning(self, "Eksik", "Müşteri seç"); return
        if self.amount.value() <= 0: QMessageBox.warning(self, "Eksik", "Tutar sıfırdan büyük olmalı"); return
        self.accept()

    def payload(self) -> dict[str, Any]:
        amount = Decimal(str(self.amount.value())); currency = self.currency.currentText()
        rate = Decimal("1") if currency == "TRY" else Decimal(str(self.fx_rate.value()))
        return {
            "customer_id": self.customer.currentData(), "sale_id": None,
            "transaction_type": self.tx_type.currentData(), "amount": str(amount), "currency": currency,
            "fx_rate_to_try": str(rate), "amount_try": str(convert_to_try(amount, currency, rate)),
            "transaction_date": self.tx_date.date().toString("yyyy-MM-dd"),
            "due_date": self.due_date.date().toString("yyyy-MM-dd") if self.has_due.isChecked() else None,
            "payment_method": self.payment_method.currentText(), "document_no": self.document_no.text().strip() or None,
            "description": self.description.toPlainText().strip() or None,
        }


class ProductDialog(QDialog):
    def __init__(self, existing: dict[str, Any] | None = None, parent=None):
        super().__init__(parent)
        self.existing = existing or {}
        self.setWindowTitle("Ürün Kartı")
        self.resize(820, 720)
        root = QVBoxLayout(self)
        tabs = QTabWidget(); root.addWidget(tabs, 1)

        general = QWidget(); gf = QFormLayout(general)
        self.product_code = QLineEdit(str(self.existing.get("product_code") or ""))
        self.barcode = QLineEdit(str(self.existing.get("barcode") or ""))
        self.name = QLineEdit(str(self.existing.get("name") or ""))
        self.invoice_name = QLineEdit(str(self.existing.get("invoice_name") or ""))
        self.subtitle = QLineEdit(str(self.existing.get("subtitle") or ""))
        self.brand = QLineEdit(str(self.existing.get("brand") or ""))
        self.category_main = QLineEdit(str(self.existing.get("category_main") or ""))
        self.category_sub1 = QLineEdit(str(self.existing.get("category_sub1") or ""))
        self.category_sub2 = QLineEdit(str(self.existing.get("category_sub2") or ""))
        self.category_sub3 = QLineEdit(str(self.existing.get("category_sub3") or ""))
        self.active = QCheckBox("Aktif ürün"); self.active.setChecked(bool(self.existing.get("is_active", True)))
        for label, widget in [
            ("Ürün kodu *", self.product_code), ("Barkod", self.barcode), ("Ürün adı *", self.name),
            ("Fatura ismi", self.invoice_name), ("Alt başlık", self.subtitle), ("Marka", self.brand),
            ("Ana kategori", self.category_main), ("Alt kategori 1", self.category_sub1),
            ("Alt kategori 2", self.category_sub2), ("Alt kategori 3", self.category_sub3), ("Durum", self.active),
        ]: gf.addRow(label, widget)
        tabs.addTab(general, "Genel")

        pricing = QWidget(); pf = QFormLayout(pricing)
        self.price_entry_mode = QComboBox()
        self.price_entry_mode.addItem("Normal / perakende ürün", "RETAIL")
        self.price_entry_mode.addItem("Doğrudan toptan ürün", "WHOLESALE_ONLY")
        wholesale_only = self.existing.get("retail_price") in (None, "") and self.existing.get("wholesale_price") not in (None, "")
        self.price_entry_mode.setCurrentIndex(1 if wholesale_only else 0)
        self.purchase = money_spin(); self.purchase.setValue(float(self.existing.get("purchase_price") or 0))
        self.retail = money_spin(); self.retail.setValue(float(self.existing.get("retail_price") or 0))
        self.wholesale = money_spin(); self.wholesale.setValue(float(self.existing.get("wholesale_price") or 0))
        self.wholesale_auto = QCheckBox("Perakende fiyatının otomatik %10 altı")
        self.wholesale_auto.setChecked(bool(self.existing.get("wholesale_auto", True)) and not wholesale_only)
        self.currency = QComboBox(); self.currency.addItems(SUPPORTED_CURRENCIES)
        idx = self.currency.findText(str(self.existing.get("currency") or "TRY")); self.currency.setCurrentIndex(max(idx, 0))
        self.vat = money_spin(100, 2); self.vat.setValue(float(self.existing.get("vat_rate") or 0))
        self.desi = money_spin(1_000_000, 3); self.desi.setValue(float(self.existing.get("desi") or 0))
        for label, widget in [
            ("Fiyat giriş türü", self.price_entry_mode), ("Alış fiyatı", self.purchase),
            ("Perakende / normal fiyat", self.retail), ("Toptan fiyat", self.wholesale),
            ("Toptan fiyat kuralı", self.wholesale_auto), ("Para birimi", self.currency),
            ("KDV oranı", self.vat), ("Desi", self.desi),
        ]: pf.addRow(label, widget)
        tabs.addTab(pricing, "Fiyat")

        details = QWidget(); df = QFormLayout(details)
        self.colors = QLineEdit(str(self.existing.get("colors") or ""))
        self.variant_type = QLineEdit(str(self.existing.get("variant_type") or ""))
        self.models = QTextEdit(str(self.existing.get("models") or "")); self.models.setMaximumHeight(70)
        self.gtip = QLineEdit(str(self.existing.get("gtip_no") or ""))
        self.origin = QLineEdit(str(self.existing.get("origin_country") or ""))
        self.html = QTextEdit(str(self.existing.get("html_description") or "")); self.html.setMinimumHeight(180)
        self.notes = QTextEdit(str(self.existing.get("notes") or "")); self.notes.setMaximumHeight(70)
        for label, widget in [
            ("Renkler", self.colors), ("Varyant türü", self.variant_type), ("Modeller", self.models),
            ("GTIP No", self.gtip), ("Menşei ülke", self.origin), ("HTML açıklama", self.html), ("Not", self.notes),
        ]: df.addRow(label, widget)
        tabs.addTab(details, "Şablon Detayları")

        integration_scroll = QScrollArea(); integration_scroll.setWidgetResizable(True)
        integration_body = QWidget(); integration_form = QFormLayout(integration_body)
        existing_integrations = self.existing.get("integration_data") or {}
        self.integration_fields: dict[str, QLineEdit] = {}
        for header in INTEGRATION_HEADERS:
            field = QLineEdit(str(existing_integrations.get(header) or ""))
            field.setPlaceholderText("E / H veya entegrasyon değeri")
            self.integration_fields[header] = field
            integration_form.addRow(header, field)
        integration_scroll.setWidget(integration_body)
        tabs.addTab(integration_scroll, "Entegrasyonlar")

        image_scroll = QScrollArea(); image_scroll.setWidgetResizable(True)
        image_body = QWidget(); image_form = QFormLayout(image_body)
        existing_images = list(self.existing.get("images") or [])
        self.image_fields: list[QLineEdit] = []
        for index, header in enumerate(IMAGE_HEADERS):
            field = QLineEdit(existing_images[index] if index < len(existing_images) else "")
            field.setPlaceholderText("https://...")
            self.image_fields.append(field)
            image_form.addRow(header, field)
        image_scroll.setWidget(image_body)
        tabs.addTab(image_scroll, "Resimler")

        self.retail.valueChanged.connect(self._sync_price_mode)
        self.wholesale_auto.toggled.connect(self._sync_price_mode)
        self.price_entry_mode.currentIndexChanged.connect(self._sync_price_mode)
        self._sync_price_mode()
        buttons = base_buttons(self); buttons.accepted.disconnect(); buttons.accepted.connect(self._accept); root.addWidget(buttons)

    def _sync_price_mode(self, *_args) -> None:
        wholesale_only = self.price_entry_mode.currentData() == "WHOLESALE_ONLY"
        self.retail.setEnabled(not wholesale_only)
        self.wholesale_auto.setEnabled(not wholesale_only)
        if wholesale_only:
            self.wholesale_auto.blockSignals(True); self.wholesale_auto.setChecked(False); self.wholesale_auto.blockSignals(False)
            self.retail.blockSignals(True); self.retail.setValue(0); self.retail.blockSignals(False)
            self.wholesale.setEnabled(True)
        else:
            self.wholesale.setEnabled(not self.wholesale_auto.isChecked())
            if self.wholesale_auto.isChecked():
                self.wholesale.blockSignals(True)
                self.wholesale.setValue(float(default_wholesale_price(self.retail.value())))
                self.wholesale.blockSignals(False)

    def _accept(self) -> None:
        if not self.product_code.text().strip() or not self.name.text().strip():
            QMessageBox.warning(self, "Eksik", "Ürün kodu ve ürün adı zorunlu")
            return
        wholesale_only = self.price_entry_mode.currentData() == "WHOLESALE_ONLY"
        if wholesale_only and self.wholesale.value() <= 0:
            QMessageBox.warning(self, "Eksik", "Doğrudan toptan üründe toptan fiyatı girmelisin")
            return
        if not wholesale_only and self.retail.value() <= 0 and self.wholesale.value() <= 0:
            QMessageBox.warning(self, "Eksik", "En az bir satış fiyatı girmelisin")
            return
        self.accept()

    def payload(self) -> dict[str, Any]:
        wholesale_only = self.price_entry_mode.currentData() == "WHOLESALE_ONLY"
        return {
            "product_code": self.product_code.text().strip(), "barcode": self.barcode.text().strip() or None,
            "name": self.name.text().strip(), "invoice_name": self.invoice_name.text().strip() or None,
            "subtitle": self.subtitle.text().strip() or None, "brand": self.brand.text().strip() or None,
            "category_main": self.category_main.text().strip() or None, "category_sub1": self.category_sub1.text().strip() or None,
            "category_sub2": self.category_sub2.text().strip() or None, "category_sub3": self.category_sub3.text().strip() or None,
            "purchase_price": str(Decimal(str(self.purchase.value()))) if self.purchase.value() > 0 else None,
            "retail_price": None if wholesale_only else (str(Decimal(str(self.retail.value()))) if self.retail.value() > 0 else None),
            "wholesale_price": str(Decimal(str(self.wholesale.value()))) if self.wholesale.value() > 0 else None,
            "wholesale_auto": False if wholesale_only else self.wholesale_auto.isChecked(),
            "currency": self.currency.currentText(),
            "vat_rate": str(Decimal(str(self.vat.value()))) if self.vat.value() > 0 else None,
            "desi": str(Decimal(str(self.desi.value()))) if self.desi.value() > 0 else None,
            "colors": self.colors.text().strip() or None, "variant_type": self.variant_type.text().strip() or None,
            "models": self.models.toPlainText().strip() or None, "gtip_no": self.gtip.text().strip() or None,
            "origin_country": self.origin.text().strip() or None, "html_description": self.html.toPlainText().strip() or None,
            "notes": self.notes.toPlainText().strip() or None,
            "integration_data": {header: field.text().strip() for header, field in self.integration_fields.items() if field.text().strip()},
            "images": [field.text().strip() for field in self.image_fields if field.text().strip()],
            "is_active": self.active.isChecked(),
        }


class ManualProductDialog(QDialog):
    def __init__(
        self,
        existing: dict[str, Any] | None = None,
        parent=None,
        price_type: str = "RETAIL",
    ):
        super().__init__(parent)
        data = existing or {}
        self.price_type = str(data.get("manual_price_type") or price_type or "RETAIL")
        self.setWindowTitle("Manuel Toptan Ürün" if self.price_type == "WHOLESALE" else "Manuel Perakende Ürün")
        self.setMinimumWidth(520)
        root = QVBoxLayout(self); form = QFormLayout()
        self.barcode = QLineEdit(str(data.get("barcode") or ""))
        self.name = QLineEdit(str(data.get("product_name") or ""))
        self.quantity = money_spin(1_000_000, 3); self.quantity.setValue(float(data.get("quantity") or 1))
        self.unit = QComboBox(); self.unit.addItems(["Adet", "Takım", "Litre", "Metre", "Paket"])
        idx = self.unit.findText(str(data.get("unit") or "Adet")); self.unit.setCurrentIndex(max(idx, 0))
        self.retail = money_spin(); self.retail.setValue(float(data.get("retail_price") or 0))
        self.wholesale = money_spin(); self.wholesale.setValue(float(data.get("wholesale_price") or 0))
        self.auto = QCheckBox("Toptan fiyatı perakendenin %10 altı yap")
        self.auto.setChecked(bool(data.get("wholesale_auto", not bool(data.get("wholesale_price")))))
        self.discount = money_spin(100, 2); self.discount.setValue(float(data.get("discount_percent") or 0))
        for label, widget in [
            ("Barkod", self.barcode), ("Ürün adı *", self.name), ("Miktar", self.quantity), ("Birim", self.unit),
        ]: form.addRow(label, widget)
        if self.price_type == "WHOLESALE":
            form.addRow("Toptan fiyat *", self.wholesale)
        else:
            form.addRow("Perakende fiyat *", self.retail)
            form.addRow("Toptan fiyat", self.wholesale)
            form.addRow("Otomatik toptan", self.auto)
        form.addRow("İndirim %", self.discount)
        root.addLayout(form)
        self.retail.valueChanged.connect(self._auto); self.auto.toggled.connect(self._auto); self._auto()
        buttons = base_buttons(self); buttons.accepted.disconnect(); buttons.accepted.connect(self._accept); root.addWidget(buttons)

    def _auto(self, *_args) -> None:
        if self.price_type == "WHOLESALE":
            self.wholesale.setEnabled(True)
            return
        self.wholesale.setEnabled(not self.auto.isChecked())
        if self.auto.isChecked():
            self.wholesale.setValue(float(default_wholesale_price(self.retail.value())))

    def _accept(self) -> None:
        if not self.name.text().strip(): QMessageBox.warning(self, "Eksik", "Ürün adı zorunlu"); return
        if self.quantity.value() <= 0: QMessageBox.warning(self, "Eksik", "Miktar sıfırdan büyük olmalı"); return
        if self.price_type == "WHOLESALE" and self.wholesale.value() <= 0:
            QMessageBox.warning(self, "Eksik", "Toptan fiyatı girmelisin"); return
        if self.price_type != "WHOLESALE" and self.retail.value() <= 0:
            QMessageBox.warning(self, "Eksik", "Perakende fiyatı girmelisin"); return
        self.accept()

    def item(self) -> dict[str, Any]:
        wholesale_only = self.price_type == "WHOLESALE"
        return {
            "product_id": None, "barcode": self.barcode.text().strip() or None, "product_code": None,
            "product_name": self.name.text().strip(), "quantity": str(Decimal(str(self.quantity.value()))),
            "unit": self.unit.currentText(),
            "retail_price": None if wholesale_only else str(Decimal(str(self.retail.value()))),
            "wholesale_price": str(Decimal(str(self.wholesale.value()))), "purchase_price": None,
            "discount_percent": str(Decimal(str(self.discount.value()))), "is_manual": True,
            "manual_price_type": self.price_type, "wholesale_auto": False if wholesale_only else self.auto.isChecked(),
        }


class ProductPickerDialog(QDialog):
    """Ürün listesini ayrı bir pencerede aratıp tek ürün seçtirir."""

    def __init__(
        self,
        product_search: Callable[[str], list[dict[str, Any]]],
        initial_query: str = "",
        parent=None,
    ):
        super().__init__(parent)
        self.product_search = product_search
        self.selected_product: dict[str, Any] | None = None
        self._workers: set[Worker] = set()
        self.setWindowTitle("Ürün Seç")
        self.resize(930, 590)

        root = QVBoxLayout(self)
        search_row = QHBoxLayout()
        self.search = QLineEdit(initial_query)
        self.search.setPlaceholderText("Barkod, ürün kodu veya ürün adı yaz")
        self.search.returnPressed.connect(self._search)
        search_button = QPushButton("Ara")
        search_button.setObjectName("PrimaryButton")
        search_button.clicked.connect(self._search)
        search_row.addWidget(self.search, 1)
        search_row.addWidget(search_button)
        root.addLayout(search_row)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Barkod", "Ürün Kodu", "Ürün Adı", "Perakende", "Toptan", "Para"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.doubleClicked.connect(self._accept_selected)
        root.addWidget(self.table, 1)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Ürünü Seç")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Vazgeç")
        buttons.accepted.connect(self._accept_selected)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        if initial_query.strip():
            QTimer.singleShot(0, self._search)
        else:
            self.search.setFocus()

    def _retain_worker(self, worker: Worker) -> None:
        self._workers.add(worker)
        worker.signals.finished.connect(lambda w=worker: self._workers.discard(w))
        QThreadPool.globalInstance().start(worker)

    def _search(self) -> None:
        query = self.search.text().strip()
        if not query:
            QMessageBox.information(self, "Ürün Ara", "Barkod, ürün kodu veya ürün adı yaz")
            return
        self.search.setEnabled(False)
        self.table.setRowCount(0)
        worker = Worker(self.product_search, query)
        worker.signals.result.connect(self._loaded)
        worker.signals.error.connect(lambda message: QMessageBox.critical(self, "Ürün Arama", message))
        worker.signals.finished.connect(lambda: self.search.setEnabled(True))
        self._retain_worker(worker)

    def _loaded(self, rows: list[dict[str, Any]]) -> None:
        self.table.setRowCount(0)
        for product in rows:
            row = self.table.rowCount()
            self.table.insertRow(row)
            retail = product.get("retail_price")
            wholesale = product.get("wholesale_price")
            values = [
                product.get("barcode") or "",
                product.get("product_code") or "",
                product.get("name") or "",
                format_money(retail, product.get("currency") or "TRY") if retail not in (None, "") else "—",
                format_money(wholesale, product.get("currency") or "TRY") if wholesale not in (None, "") else "—",
                product.get("currency") or "TRY",
            ]
            for col, value in enumerate(values):
                cell = QTableWidgetItem(str(value))
                if col == 0:
                    cell.setData(ROLE_ITEM, product)
                self.table.setItem(row, col, cell)
        if self.table.rowCount():
            self.table.selectRow(0)
        else:
            QMessageBox.information(self, "Ürün Ara", "Eşleşen ürün bulunamadı. Ürünü satış ekranına manuel yazabilirsin.")

    def _accept_selected(self, *_args) -> None:
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Ürün Seç", "Listeden bir ürün seç")
            return
        cell = self.table.item(row, 0)
        product = cell.data(ROLE_ITEM) if cell else None
        if not isinstance(product, dict):
            return
        self.selected_product = product
        self.accept()


class CustomerSaleDialog(QDialog):
    """Kasiyer tipi sade müşteri satış ekranı."""

    def __init__(
        self, customers: list[dict[str, Any]], product_search: Callable[[str], list[dict[str, Any]]],
        branch_name: str, existing: dict[str, Any] | None = None, parent=None,
    ):
        super().__init__(parent)
        self.customers = customers
        self.product_search = product_search
        self.existing = existing or {}
        self.items: list[dict[str, Any]] = []
        self._workers: set[Worker] = set()
        self._entry_product: dict[str, Any] | None = None
        self.setWindowTitle("Hızlı Müşteri Satışı")
        self.resize(1180, 780)

        root = QVBoxLayout(self)
        banner = QLabel(f"Kayıt şubesi: {branch_name}")
        banner.setStyleSheet("background:#fff0f0;color:#8f1111;padding:9px;border:1px solid #efc2c2;font-weight:700;")
        root.addWidget(banner)

        top = QFrame(); top.setObjectName("Card"); top_layout = QHBoxLayout(top)
        self.customer = QComboBox(); self.customer.setMinimumWidth(250)
        for row in customers:
            self.customer.addItem(row["name"], row["id"])
        self.sale_date = QDateEdit(QDate.currentDate()); self.sale_date.setCalendarPopup(True)
        self.due_enabled = QCheckBox("Vadeli")
        self.due_date = QDateEdit(QDate.currentDate().addDays(30)); self.due_date.setCalendarPopup(True); self.due_date.setEnabled(False)
        self.currency = QComboBox(); self.currency.addItems(SUPPORTED_CURRENCIES)
        self.fx_rate = rate_spin(); self.fx_rate.setEnabled(False)
        for label, widget in [
            ("Müşteri", self.customer), ("Tarih", self.sale_date), ("", self.due_enabled),
            ("Vade", self.due_date), ("Para", self.currency), ("Kur", self.fx_rate),
        ]:
            if label:
                top_layout.addWidget(QLabel(label))
            top_layout.addWidget(widget)
        root.addWidget(top)
        self.due_enabled.toggled.connect(self.due_date.setEnabled)
        self.currency.currentTextChanged.connect(self._currency_changed)

        entry = QFrame(); entry.setObjectName("Card")
        el = QGridLayout(entry)
        el.setHorizontalSpacing(10); el.setVerticalSpacing(8)

        self.barcode = QLineEdit()
        self.barcode.setPlaceholderText("Barkod okut veya manuel yaz")
        self.barcode.returnPressed.connect(self._barcode_entered)
        self.barcode.textEdited.connect(self._entry_edited)

        self.product_name = QLineEdit()
        self.product_name.setPlaceholderText("Ürün adını manuel yaz veya sağdaki ... ile seç")
        self.product_name.textEdited.connect(self._entry_edited)
        self.product_name.returnPressed.connect(self._add_entry)

        pick = QPushButton("...")
        pick.setObjectName("SecondaryButton")
        pick.setFixedWidth(44)
        pick.setToolTip("Ürün listesinden seç")
        pick.clicked.connect(self._pick_product)

        self.qty = money_spin(1_000_000, 3); self.qty.setValue(1); self.qty.setMaximumWidth(130)
        self.unit = QComboBox(); self.unit.addItems(["Adet", "Takım", "Litre", "Metre", "Paket"]); self.unit.setMaximumWidth(120)
        self.entry_price = money_spin(); self.entry_price.setMaximumWidth(180)
        self.entry_total = QLabel(format_money(0, "TRY"))
        self.entry_total.setStyleSheet("font-size:20px;font-weight:900;color:#101820;")
        self.discount = money_spin(100, 2); self.discount.setMaximumWidth(100)
        add = QPushButton("+ EKLE")
        add.setObjectName("PrimaryButton")
        add.setMinimumHeight(42)
        add.clicked.connect(self._add_entry)

        el.addWidget(QLabel("Barkod"), 0, 0)
        el.addWidget(self.barcode, 0, 1, 1, 2)
        el.addWidget(QLabel("Ürün Adı"), 1, 0)
        el.addWidget(self.product_name, 1, 1)
        el.addWidget(pick, 1, 2)
        el.addWidget(QLabel("Miktar"), 0, 3)
        el.addWidget(self.qty, 0, 4)
        el.addWidget(self.unit, 0, 5)
        el.addWidget(QLabel("Fiyat"), 1, 3)
        el.addWidget(self.entry_price, 1, 4)
        el.addWidget(QLabel("İndirim %"), 1, 5)
        el.addWidget(self.discount, 1, 6)
        el.addWidget(QLabel("Tutar"), 0, 6)
        el.addWidget(self.entry_total, 0, 7)
        el.addWidget(add, 1, 7)
        el.setColumnStretch(1, 1)
        root.addWidget(entry)

        self.qty.valueChanged.connect(self._update_entry_total)
        self.entry_price.valueChanged.connect(self._update_entry_total)
        self.discount.valueChanged.connect(self._update_entry_total)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Barkod", "Ürün Adı", "Miktar", "Birim", "Fiyat", "Tutar"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.doubleClicked.connect(self._edit_selected)
        root.addWidget(self.table, 1)

        bottom = QFrame(); bottom.setObjectName("Card"); bl = QHBoxLayout(bottom)
        self.price_group = QButtonGroup(self)
        self.price_group.setExclusive(True)
        self.retail_button = QPushButton("PERAKENDE")
        self.wholesale_button = QPushButton("TOPTAN")
        for button in (self.retail_button, self.wholesale_button):
            button.setCheckable(True)
            button.setMinimumSize(118, 48)
            button.setStyleSheet(
                "QPushButton{border:1px solid #aeb8c2;border-radius:7px;background:#f2f4f6;color:#24313c;font-weight:800;}"
                "QPushButton:checked{background:#d71920;color:white;border-color:#d71920;}"
            )
            self.price_group.addButton(button)
        self.retail_button.setChecked(True)
        self.retail_radio = self.retail_button
        self.wholesale_radio = self.wholesale_button
        self.price_group.buttonToggled.connect(self._price_type_changed)

        self.price_mode_hint = QLabel("Sepet fiyatı: PERAKENDE")
        self.price_mode_hint.setStyleSheet("color:#68737e;font-weight:700;")
        remove = QPushButton("Satır Sil")
        remove.setObjectName("DangerButton")
        remove.clicked.connect(self._remove_selected)
        self.payment_method = QComboBox(); self.payment_method.addItems(["Nakit", "Kredi kartı", "Havale / EFT", "Cari / Vadeli", "Parçalı ödeme", "Diğer"])
        self.paid = money_spin()
        self.document_no = QLineEdit(); self.document_no.setPlaceholderText("Belge no")
        self.notes = QLineEdit(); self.notes.setPlaceholderText("Açıklama / not")
        self.total_label = QLabel("₺ 0,00")
        self.total_label.setStyleSheet("font-size:32px;font-weight:900;color:#101820;")

        for widget in [
            self.wholesale_button, self.retail_button, self.price_mode_hint, remove,
            QLabel("Ödenen"), self.paid, self.payment_method, self.document_no, self.notes,
        ]:
            bl.addWidget(widget)
        bl.addStretch()
        bl.addWidget(self.total_label)
        root.addWidget(bottom)

        buttons = base_buttons(self)
        buttons.accepted.disconnect()
        buttons.accepted.connect(self._accept)
        root.addWidget(buttons)
        self._load_existing()
        self._update_entry_total()
        self.barcode.setFocus()

    def _retain_worker(self, worker: Worker) -> None:
        self._workers.add(worker)
        worker.signals.finished.connect(lambda w=worker: self._workers.discard(w))
        QThreadPool.globalInstance().start(worker)

    def _currency_changed(self, currency: str) -> None:
        if currency == "TRY":
            self.fx_rate.setValue(1)
            self.fx_rate.setEnabled(False)
        else:
            self.fx_rate.setEnabled(True)
        self._update_entry_total()
        self._refresh_table()

    def _entry_edited(self, *_args) -> None:
        self._entry_product = None

    def _pick_product(self) -> None:
        initial = self.product_name.text().strip() or self.barcode.text().strip()
        dialog = ProductPickerDialog(self.product_search, initial, self)
        if dialog.exec() and dialog.selected_product:
            self._load_product_to_entry(dialog.selected_product)

    def _barcode_entered(self) -> None:
        barcode = self.barcode.text().strip()
        if not barcode:
            self.product_name.setFocus()
            return
        self.barcode.setEnabled(False)
        worker = Worker(self.product_search, barcode)
        worker.signals.result.connect(lambda rows, code=barcode: self._barcode_loaded(code, rows))
        worker.signals.error.connect(lambda message: QMessageBox.critical(self, "Barkod Arama", message))
        worker.signals.finished.connect(lambda: self.barcode.setEnabled(True))
        self._retain_worker(worker)

    def _barcode_loaded(self, barcode: str, rows: list[dict[str, Any]]) -> None:
        exact = next((row for row in rows if str(row.get("barcode") or "").strip() == barcode), None)
        if exact is None and len(rows) == 1:
            exact = rows[0]
        if exact is not None:
            self._load_product_to_entry(exact)
            self.qty.setFocus()
            self.qty.selectAll()
        else:
            self._entry_product = None
            self.product_name.setFocus()

    @staticmethod
    def _prices(product: dict[str, Any]) -> tuple[Decimal | None, Decimal | None]:
        retail_raw = product.get("retail_price")
        wholesale_raw = product.get("wholesale_price")
        retail = Decimal(str(retail_raw)) if retail_raw not in (None, "") else None
        wholesale = (
            Decimal(str(wholesale_raw)) if wholesale_raw not in (None, "")
            else (default_wholesale_price(retail) if retail is not None else None)
        )
        return retail, wholesale

    def _load_product_to_entry(self, product: dict[str, Any]) -> None:
        self._entry_product = dict(product)
        self.barcode.setText(str(product.get("barcode") or ""))
        self.product_name.setText(str(product.get("name") or ""))
        product_currency = str(product.get("currency") or "TRY")
        if not self.items:
            idx = self.currency.findText(product_currency)
            if idx >= 0:
                self.currency.setCurrentIndex(idx)
        retail, wholesale = self._prices(product)
        selected = wholesale if retail is None and wholesale is not None else (retail if self._price_type() == "RETAIL" else wholesale)
        self.entry_price.setValue(float(selected or 0))
        self._update_entry_total()

    def _update_entry_total(self, *_args) -> None:
        total = line_total(self.qty.value(), self.entry_price.value(), self.discount.value())
        self.entry_total.setText(format_money(total, self.currency.currentText()))

    def _add_entry(self) -> None:
        name = self.product_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Eksik", "Ürün adını yaz veya ... butonundan ürün seç")
            return
        if self.qty.value() <= 0:
            QMessageBox.warning(self, "Eksik", "Miktar sıfırdan büyük olmalı")
            return
        if self.entry_price.value() <= 0:
            QMessageBox.warning(self, "Eksik", "Fiyat sıfırdan büyük olmalı")
            return

        quantity = str(Decimal(str(self.qty.value())))
        discount = str(Decimal(str(self.discount.value())))
        entered_price = Decimal(str(self.entry_price.value()))

        if self._entry_product is not None:
            product = self._entry_product
            retail, wholesale = self._prices(product)
            wholesale_only = retail is None and wholesale is not None
            item = {
                "product_id": product.get("id"),
                "barcode": product.get("barcode"),
                "product_code": product.get("product_code"),
                "product_name": product.get("name") or name,
                "quantity": quantity,
                "unit": self.unit.currentText(),
                "retail_price": str(retail) if retail is not None else None,
                "wholesale_price": str(wholesale) if wholesale is not None else None,
                "purchase_price": str(product.get("purchase_price")) if product.get("purchase_price") is not None else None,
                "discount_percent": discount,
                "is_manual": False,
                "manual_price_type": "WHOLESALE" if wholesale_only else None,
                "wholesale_only": wholesale_only,
            }
            # Seçilen sistem ürününün fiyatı kutuda elle değiştirildiyse satış satırına uygula.
            normal_price = self._item_unit_price(item)
            if normal_price is None or entered_price != normal_price:
                if item.get("wholesale_only") or self._price_type() == "WHOLESALE":
                    item["wholesale_price"] = str(entered_price)
                else:
                    item["retail_price"] = str(entered_price)
                    if wholesale is None:
                        item["wholesale_price"] = str(default_wholesale_price(entered_price))
        else:
            if self._price_type() == "WHOLESALE":
                retail_value = None
                wholesale_value = entered_price
                manual_price_type = "WHOLESALE"
                wholesale_only = True
            else:
                retail_value = entered_price
                wholesale_value = default_wholesale_price(entered_price)
                manual_price_type = "RETAIL"
                wholesale_only = False
            item = {
                "product_id": None,
                "barcode": self.barcode.text().strip() or None,
                "product_code": None,
                "product_name": name,
                "quantity": quantity,
                "unit": self.unit.currentText(),
                "retail_price": str(retail_value) if retail_value is not None else None,
                "wholesale_price": str(wholesale_value),
                "purchase_price": None,
                "discount_percent": discount,
                "is_manual": True,
                "manual_price_type": manual_price_type,
                "wholesale_only": wholesale_only,
                "wholesale_auto": not wholesale_only,
            }

        existing_index = next((
            index for index, current in enumerate(self.items)
            if current.get("product_id") and current.get("product_id") == item.get("product_id")
        ), None)
        if existing_index is not None:
            current_qty = Decimal(str(self.items[existing_index].get("quantity") or 0))
            self.items[existing_index]["quantity"] = str(current_qty + Decimal(quantity))
        else:
            self.items.append(item)
        self._refresh_table()
        self._clear_entry()

    def _clear_entry(self) -> None:
        self._entry_product = None
        self.barcode.clear()
        self.product_name.clear()
        self.qty.setValue(1)
        self.unit.setCurrentIndex(0)
        self.entry_price.setValue(0)
        self.discount.setValue(0)
        self.barcode.setFocus()

    def _selected_index(self) -> int:
        return self.table.currentRow()

    def _edit_selected(self, *_args) -> None:
        idx = self._selected_index()
        if idx < 0:
            return
        current = self.items[idx]
        locked_wholesale = bool(current.get("wholesale_only")) or current.get("manual_price_type") == "WHOLESALE"
        dialog = ManualProductDialog(
            current,
            self,
            price_type="WHOLESALE" if locked_wholesale else self._price_type(),
        )
        if dialog.exec():
            edited = dialog.item()
            if current.get("product_id"):
                edited.update({key: current.get(key) for key in ("product_id", "product_code", "purchase_price")})
                edited["is_manual"] = False
            edited["wholesale_only"] = locked_wholesale
            self.items[idx] = edited
            self._refresh_table()

    def _remove_selected(self) -> None:
        idx = self._selected_index()
        if idx >= 0:
            self.items.pop(idx)
            self._refresh_table()

    def _price_type_changed(self, button: QPushButton, checked: bool) -> None:
        if not checked:
            return
        if self._entry_product is not None:
            retail, wholesale = self._prices(self._entry_product)
            selected = wholesale if retail is None and wholesale is not None else (retail if self._price_type() == "RETAIL" else wholesale)
            self.entry_price.setValue(float(selected or 0))
        self._refresh_table()

    def _price_type(self) -> str:
        return "RETAIL" if self.retail_button.isChecked() else "WHOLESALE"

    def _item_unit_price(self, item: dict[str, Any]) -> Decimal | None:
        retail_raw = item.get("retail_price")
        wholesale_raw = item.get("wholesale_price")
        retail = Decimal(str(retail_raw)) if retail_raw not in (None, "") else None
        wholesale = (
            Decimal(str(wholesale_raw)) if wholesale_raw not in (None, "")
            else (default_wholesale_price(retail) if retail is not None else None)
        )
        if item.get("wholesale_only") or item.get("manual_price_type") == "WHOLESALE":
            return wholesale
        return retail if self._price_type() == "RETAIL" else wholesale

    def _refresh_table(self) -> None:
        self.table.setRowCount(0)
        total = Decimal("0")
        for item in self.items:
            selected = self._item_unit_price(item) or Decimal("0")
            item["unit_price"] = str(selected)
            row_total = line_total(item.get("quantity"), selected, item.get("discount_percent"))
            total += row_total
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                item.get("barcode") or "",
                item.get("product_name") or "",
                item.get("quantity") or "",
                item.get("unit") or "Adet",
                format_money(selected, self.currency.currentText()),
                format_money(row_total, self.currency.currentText()),
            ]
            for col, value in enumerate(values):
                cell = QTableWidgetItem(str(value))
                if col == 0:
                    cell.setData(ROLE_ITEM, item)
                self.table.setItem(row, col, cell)
        self.price_mode_hint.setText("Sepet fiyatı: PERAKENDE" if self._price_type() == "RETAIL" else "Sepet fiyatı: TOPTAN")
        self.total_label.setText(format_money(total, self.currency.currentText()))
        self.paid.setMaximum(float(total))

    def _load_existing(self) -> None:
        if not self.existing:
            return
        idx = self.customer.findData(self.existing.get("customer_id")); self.customer.setCurrentIndex(max(idx, 0))
        if self.existing.get("sale_date"):
            self.sale_date.setDate(QDate.fromString(str(self.existing["sale_date"])[:10], "yyyy-MM-dd"))
        if self.existing.get("due_date"):
            self.due_enabled.setChecked(True)
            self.due_date.setDate(QDate.fromString(str(self.existing["due_date"])[:10], "yyyy-MM-dd"))
        if self.existing.get("price_type") == "WHOLESALE":
            self.wholesale_button.setChecked(True)
        idx = self.currency.findText(str(self.existing.get("currency") or "TRY")); self.currency.setCurrentIndex(max(idx, 0))
        self.fx_rate.setValue(float(self.existing.get("fx_rate_to_try") or 1))
        self.paid.setValue(float(self.existing.get("paid_at_sale") or 0))
        idx = self.payment_method.findText(str(self.existing.get("payment_method") or ""))
        if idx >= 0:
            self.payment_method.setCurrentIndex(idx)
        self.document_no.setText(str(self.existing.get("document_no") or ""))
        self.notes.setText(str(self.existing.get("notes") or ""))
        raw_items = self.existing.get("customer_sale_items") or []
        self.items = []
        for row in raw_items:
            retail = row.get("retail_price_snapshot")
            wholesale = row.get("wholesale_price_snapshot")
            wholesale_only = retail in (None, "") and wholesale not in (None, "")
            self.items.append({
                "product_id": row.get("product_id"),
                "barcode": row.get("barcode_snapshot"),
                "product_code": row.get("product_code_snapshot"),
                "product_name": row.get("product_name_snapshot"),
                "quantity": str(row.get("quantity") or 1),
                "unit": row.get("unit") or "Adet",
                "retail_price": str(retail) if retail is not None else None,
                "wholesale_price": str(wholesale) if wholesale is not None else None,
                "purchase_price": str(row.get("purchase_price_snapshot")) if row.get("purchase_price_snapshot") is not None else None,
                "discount_percent": str(row.get("discount_percent") or 0),
                "is_manual": bool(row.get("is_manual")),
                "manual_price_type": "WHOLESALE" if wholesale_only else None,
                "wholesale_only": wholesale_only,
            })
        self._refresh_table()

    def _accept(self) -> None:
        if not self.customer.currentData():
            QMessageBox.warning(self, "Eksik", "Müşteri seç")
            return
        if not self.items:
            QMessageBox.warning(self, "Eksik", "En az bir ürün ekle")
            return
        for item in self.items:
            selected = self._item_unit_price(item)
            if selected is None or selected <= 0:
                QMessageBox.warning(self, "Fiyat Eksik", f"{item.get('product_name') or 'Ürün'} için uygulanacak fiyat tanımlı değil")
                return
        total = sum((line_total(item["quantity"], self._item_unit_price(item), item.get("discount_percent")) for item in self.items), Decimal("0"))
        if Decimal(str(self.paid.value())) > total:
            QMessageBox.warning(self, "Hatalı", "Ödenen tutar toplamdan büyük olamaz")
            return
        self.accept()

    def payload(self, branch_id: str) -> dict[str, Any]:
        currency = self.currency.currentText()
        rate = Decimal("1") if currency == "TRY" else Decimal(str(self.fx_rate.value()))
        items = []
        for item in self.items:
            copy = dict(item)
            selected = self._item_unit_price(copy)
            copy["unit_price"] = str(selected) if selected is not None else None
            items.append(copy)
        base = {
            "p_customer_id": self.customer.currentData(),
            "p_sale_date": self.sale_date.date().toString("yyyy-MM-dd"),
            "p_price_type": self._price_type(),
            "p_currency": currency,
            "p_fx_rate_to_try": str(rate),
            "p_due_date": self.due_date.date().toString("yyyy-MM-dd") if self.due_enabled.isChecked() else None,
            "p_payment_method": self.payment_method.currentText(),
            "p_document_no": self.document_no.text().strip() or None,
            "p_notes": self.notes.text().strip() or None,
            "p_paid_amount": str(Decimal(str(self.paid.value()))),
            "p_items": items,
        }
        if self.existing.get("id"):
            return {**base, "p_sale_id": self.existing["id"]}
        return {**base, "p_branch_id": branch_id}
